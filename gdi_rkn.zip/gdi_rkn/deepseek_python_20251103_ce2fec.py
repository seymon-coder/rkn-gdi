import tkinter as tk
import random
from PIL import Image, ImageTk
import os

class FlyingWindow:
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("Роскомнадзор")
        self.root.overrideredirect(True)
        self.root.attributes('-topmost', True)
        
        # Загружаем изображение Роскомнадзора
        try:
            # Создаем простое изображение Роскомнадзора программно, если файла нет
            self.create_roskomnadzor_image()
            self.image = Image.open("roskomnadzor.png")
            self.photo = ImageTk.PhotoImage(self.image)
            
            # Устанавливаем размер окна по размеру изображения
            self.width = self.image.width
            self.height = self.image.height
        except Exception as e:
            print(f"Ошибка загрузки изображения: {e}")
            # Если не удалось загрузить изображение, создаем текстовую версию
            self.photo = None
            self.width = 300
            self.height = 150
        
        # Получаем размеры экрана
        self.screen_width = self.root.winfo_screenwidth()
        self.screen_height = self.root.winfo_screenheight()
        
        # Начальные координаты (центр экрана)
        self.x = (self.screen_width - self.width) // 2
        self.y = (self.screen_height - self.height) // 2
        self.root.geometry(f"{self.width}x{self.height}+{self.x}+{self.y}")
        
        # Создаем виджет для изображения или текста
        if self.photo:
            self.label = tk.Label(self.root, image=self.photo, bg="white")
        else:
            self.label = tk.Label(
                self.root,
                text="РОСКОМНАДЗОР",
                font=("Arial", 20, "bold"),
                bg="red",
                fg="white"
            )
        self.label.pack(expand=True, fill='both')
        
        # Привязываем обработчики клавиш
        self.root.bind('<Alt-F4>', self.close_window)
        self.root.bind('<Escape>', self.close_window)
        self.root.bind('<Key>', self.key_press)
        
        # Флаг, указывающий, завершена ли анимация появления
        self.animation_complete = False
        
        # Счетчик для анимации
        self.animation_step = 0
        self.animation_size = 10  # Начинаем с маленького размера
        
        # Запускаем анимацию появления
        self.fade_in()
        
    def create_roskomnadzor_image(self):
        """Создает простое изображение Роскомнадзора, если файла нет"""
        if not os.path.exists("roskomnadzor.png"):
            from PIL import Image, ImageDraw, ImageFont
            
            # Создаем изображение
            img = Image.new('RGB', (300, 150), color='red')
            d = ImageDraw.Draw(img)
            
            # Добавляем текст
            try:
                font = ImageFont.truetype("arial.ttf", 24)
            except:
                font = ImageFont.load_default()
            
            d.text((50, 50), "РОСКОМНАДЗОР", fill='white', font=font)
            d.text((80, 80), "ЗАБЛОКИРОВАН", fill='white', font=font)
            
            # Сохраняем изображение
            img.save("roskomnadzor.png")
    
    def fade_in(self):
        """Плавное появление окна с увеличением размера"""
        if self.animation_step < 10:
            # Увеличиваем размер окна
            current_width = int(self.width * (self.animation_step / 10))
            current_height = int(self.height * (self.animation_step / 10))
            
            # Пересчитываем позицию для центрирования
            current_x = self.x + (self.width - current_width) // 2
            current_y = self.y + (self.height - current_height) // 2
            
            self.root.geometry(f"{current_width}x{current_height}+{current_x}+{current_y}")
            
            self.animation_step += 1
            self.root.after(50, self.fade_in)
        else:
            # Устанавливаем окончательный размер
            self.root.geometry(f"{self.width}x{self.height}+{self.x}+{self.y}")
            self.animation_complete = True
            self.start_movement()
    
    def start_movement(self):
        """Начинаем движение окна"""
        # Устанавливаем случайное направление движения
        self.dx = random.choice([-5, -4, 4, 5])
        self.dy = random.choice([-5, -4, 4, 5])
        
        # Запускаем движение
        self.move_window()
    
    def move_window(self):
        """Перемещение окна по экрану"""
        if not self.animation_complete:
            return
            
        # Обновляем позицию
        self.x += self.dx
        self.y += self.dy
        
        # Отскакиваем от границ экрана
        if self.x <= 0:
            self.dx = abs(self.dx)
            self.x = 0
        elif self.x + self.width >= self.screen_width:
            self.dx = -abs(self.dx)
            self.x = self.screen_width - self.width
            
        if self.y <= 0:
            self.dy = abs(self.dy)
            self.y = 0
        elif self.y + self.height >= self.screen_height:
            self.dy = -abs(self.dy)
            self.y = self.screen_height - self.height
        
        # Применяем новую позицию
        self.root.geometry(f"+{self.x}+{self.y}")
        
        # Планируем следующее перемещение
        self.root.after(1, self.move_window)
    
    def key_press(self, event):
        """Обработчик нажатия клавиш"""
        # Проверяем, нажаты ли одновременно Alt и F4
        if event.keysym == 'F4' and (event.state & 0x20000):  # 0x20000 - это модификатор Alt
            self.close_window()
    
    def close_window(self, event=None):
        """Закрытие окна"""
        self.root.quit()
        self.root.destroy()
    
    def run(self):
        self.root.mainloop()

if __name__ == "__main__":
    flying_window = FlyingWindow()
    flying_window.run()